#!/bin/bash
gnome-terminal -- '/home/'$(whoami)'/.config/updateMGR/root_shell/root_shell3.sh'