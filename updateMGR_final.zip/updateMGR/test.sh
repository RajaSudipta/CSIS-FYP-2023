#!/bin/bash
sh -c "/home/"$(whoami)"/.config/updateMGR/ask_pass.sh; exec bash"