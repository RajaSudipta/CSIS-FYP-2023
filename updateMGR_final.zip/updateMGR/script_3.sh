#!/bin/bash
gnome-terminal -- '/home/'$(whoami)'/.config/updateMGR/test.sh'